package net.sananelazim.sananelazim;

/**
 * Created by CanBerk on 28-May-17.
 */

public class AppConfig {
    public static String URL_LOGIN    = "http://sananelazim.net/login.php";
    public static String URL_REGISTER = "http://sananelazim.net/register.php";
}
